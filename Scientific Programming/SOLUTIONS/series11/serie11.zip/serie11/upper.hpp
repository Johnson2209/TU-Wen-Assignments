#ifndef _UPPER_TRIANGULAR_MATRIX_
#define _UPPER_TRIANGULAR_MATRIX_

#include <cmath>
#include <cassert>
#include <iostream>
#include "vector.hpp"

// This class stores upper triangular matrices in Rnxn

 class UpperTriangularMatrix {
   private:
   // dimension of the upper triangular matrix
      int dim;
   // dynamic coefficient upper triangular matrix
      double* coeff;

   public:
   // constructors, assignment and destructor
     // UpperTriangularMatrix();
     UpperTriangularMatrix(int n = 0, double init = 0);
     UpperTriangularMatrix(const UpperTriangularMatrix& rhs);
     UpperTriangularMatrix& operator=(const UpperTriangularMatrix& rhs);
     ~UpperTriangularMatrix();

    // mutator functions
     int size() const;
   // read and write entries
     const double& operator()(int j, int k) const;
     double& operator() (int j, int k);

    // print and norms
      double columnSumNorm() const;
      double rowSumNorm() const;

   // // return upper triangular matrix dimension
   //   int size();
   //
   // // read and write upper triangular matrix uicients
   //   void set(int k, char typ, double value);
   //   double get(int n, char typ = 'F');
   //   double get(int j, int k, char typ = 'F');
   //
   // // reads and prints a upper triangular matrix
   //   void scanUpperTriangularMatrix(int n, char type);
   //   void printUpperTriangularMatrix();
   //

   //
   //  // other functions
   //   double trace();
   //   // bool isDiagonal();
   //   // bool isSymmetric();
   //   // bool isSkewSymmetric();



 };

 std::ostream& operator<<(std::ostream& output, const UpperTriangularMatrix& mat);

 // addition of upper triangular matricess
 const UpperTriangularMatrix operator+(const UpperTriangularMatrix&, const UpperTriangularMatrix&);
 // multiplication of upper triangular matrices
 const UpperTriangularMatrix operator*(const UpperTriangularMatrix&, const UpperTriangularMatrix&);
 const Vector operator*(const UpperTriangularMatrix&, const Vector&);
 // multiplication of upper triangular matrices
 const Vector operator|(const UpperTriangularMatrix&, const Vector&);
#endif
